package com.bank.Bank_ChatBot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankChatBotApplication {

	public static void main(String[] args) {
		SpringApplication.run(BankChatBotApplication.class, args);
	}

}
