package com.bank.Bank_ChatBot.controllers;

import com.bank.Bank_ChatBot.services.ChatService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api") // <— everything under /api
public class ChatController {

    private final ChatService chatService;

    public ChatController(ChatService chatService) {
        this.chatService = chatService;
    }

    // simple GET so you can hit http://localhost:8080/api/chat in the browser to verify mapping
    @GetMapping("/chat")
    public ChatResponse ping() {
        return new ChatResponse("chat endpoint is alive");
    }

    // POST used by the UI (no consumes constraint to avoid 415/404 mismatches)
    @PostMapping(value = "/chat", produces = "application/json")
    public ChatResponse chat(@RequestBody ChatRequest body) {
        String reply = chatService.getResponse(body == null ? "" : body.getMessage());
        return new ChatResponse(reply);
    }

    // --- DTOs ---
    public static class ChatRequest {
        private String message;
        public String getMessage() { return message; }
        public void setMessage(String message) { this.message = message; }
    }
    public static class ChatResponse {
        private String response;
        public ChatResponse() {}
        public ChatResponse(String response) { this.response = response; }
        public String getResponse() { return response; }
        public void setResponse(String response) { this.response = response; }
    }
}
