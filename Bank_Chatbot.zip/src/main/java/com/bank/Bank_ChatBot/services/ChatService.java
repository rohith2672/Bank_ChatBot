package com.bank.Bank_ChatBot.services;

import com.bank.Bank_ChatBot.entities.Account;
import com.bank.Bank_ChatBot.entities.Customer;
import com.bank.Bank_ChatBot.repositories.AccountRepository;
import com.bank.Bank_ChatBot.repositories.CustomerRepository;
import com.bank.Bank_ChatBot.repositories.LoanRepository;
import com.bank.Bank_ChatBot.repositories.TransactionRepository;
import org.springframework.stereotype.Service;

import java.text.NumberFormat;
import java.util.Comparator;
import java.util.Locale;
import java.util.stream.Collectors;

@Service
public class ChatService {

    private final CustomerRepository customerRepository;
    private final AccountRepository accountRepository;
    private final TransactionRepository transactionRepository;
    private final LoanRepository loanRepository;

    public ChatService(CustomerRepository customerRepository,
                       AccountRepository accountRepository,
                       TransactionRepository transactionRepository,
                       LoanRepository loanRepository) {
        this.customerRepository = customerRepository;
        this.accountRepository = accountRepository;
        this.transactionRepository = transactionRepository;
        this.loanRepository = loanRepository;
    }

    public String getResponse(String rawMessage) {
        String message = (rawMessage == null ? "" : rawMessage).trim().toLowerCase(Locale.ROOT);

        try {
            // list customers
            if (message.equals("list customers") || message.equals("customers")) {
                var customers = customerRepository.findAll().stream()
                        .sorted(Comparator.comparing(Customer::getId))
                        .map(c -> String.format("%d — %s (%s)", c.getId(),
                                nvl(c.getFullName(), "No Name"),
                                nvl(c.getEmail(), "no-email")))
                        .collect(Collectors.toList());
                return customers.isEmpty() ? "No customers found." : String.join("\n", customers);
            }

            // customer {id}
            if (message.startsWith("customer ")) {
                Integer id = safeInt(message.replace("customer", "").trim());
                if (id == null) return "Please provide a valid customer id.";
                var custOpt = customerRepository.findById(id);
                if (custOpt.isEmpty()) return "Customer " + id + " not found.";
                var c = custOpt.get();
                var accounts = c.getAccounts() == null ? 0 : c.getAccounts().size();
                var loans    = c.getLoans() == null ? 0 : c.getLoans().size();
                return "Customer " + c.getId() + " — " + nvl(c.getFullName(), "No Name")
                        + "\nEmail: " + nvl(c.getEmail(), "no-email")
                        + "\nAccounts: " + accounts
                        + "\nLoans: " + loans;
            }

            // accounts for customer {id}
            if (message.startsWith("accounts for customer ")) {
                Integer id = safeInt(message.replace("accounts for customer", "").trim());
                if (id == null) return "Please provide a valid customer id.";
                var accounts = accountRepository.findByCustomerId(id).stream()
                        .sorted(Comparator.comparing(Account::getId))
                        .map(a -> "Account " + a.getId() + " — " + nvl(a.getType(), "unknown")
                                + " — " + money(a.getBalance()))
                        .collect(Collectors.toList());
                return accounts.isEmpty()
                        ? "No accounts found for customer " + id + "."
                        : String.join("\n", accounts);
            }

            // balance for account {id}
            if (message.startsWith("balance for account ")) {
                Integer id = safeInt(message.replace("balance for account", "").trim());
                if (id == null) return "Please provide a valid account id.";
                var accOpt = accountRepository.findById(id);
                if (accOpt.isEmpty()) return "Account " + id + " not found.";
                return "Balance for account " + id + ": " + money(accOpt.get().getBalance());
            }

            // default help
            return """
                   Hi! I can answer:
                   • list customers
                   • customer {id}
                   • accounts for customer {id}
                   • balance for account {id}
                   """;
        } catch (Exception ex) {
            ex.printStackTrace();
            return "Sorry — I hit an error.";
        }
    }

    private static Integer safeInt(String s) {
        try { return Integer.parseInt(s); } catch (Exception e) { return null; }
    }
    private static String nvl(String s, String fallback) { return (s == null || s.isBlank()) ? fallback : s; }
    private static String money(Double v) {
        if (v == null) return "-";
        return NumberFormat.getCurrencyInstance(Locale.US).format(v);
        }
}
