const chatEl = document.getElementById('chat');
const formEl = document.getElementById('composer-form');
const inputEl = document.getElementById('prompt');
const sendBtn = document.getElementById('send');
const suggestionsEl = document.getElementById('suggestions');
const tpl = document.getElementById('msg-template');

let isSending = false;

// seed welcome
window.addEventListener('load', () => {
  addBot("Hi! Ask me about customers, accounts, transactions, or loans.\nTry the buttons below to get started.");
});

// suggestions click
suggestionsEl.addEventListener('click', (e) => {
  if (e.target.classList.contains('suggestion')) {
    inputEl.value = e.target.textContent;
    inputEl.dispatchEvent(new Event('input'));
    formEl.requestSubmit();
  }
});

// enable send on input
inputEl.addEventListener('input', () => {
  sendBtn.disabled = !inputEl.value.trim() || isSending;
  autoGrow(inputEl);
});

// Enter: send; Shift+Enter: newline
inputEl.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    formEl.requestSubmit();
  }
});

formEl.addEventListener('submit', async (e) => {
  e.preventDefault();
  const text = inputEl.value.trim();
  if (!text || isSending) return;

  isSending = true;
  sendBtn.disabled = true;

  addUser(text);
  inputEl.value = '';
  autoGrow(inputEl);

  // typing placeholder
  const typing = addBot('…', true);

  try {
    const res = await fetch('/api/chat', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({ prompt: text })
    });

    if (!res.ok) throw new Error(`HTTP ${res.status}`);

    // Support both JSON {reply:""} or plain text
    let reply;
    const ctype = res.headers.get('content-type') || '';
    if (ctype.includes('application/json')) {
      const data = await res.json();
      reply = data.reply ?? data.message ?? JSON.stringify(data);
    } else {
      reply = await res.text();
    }

    replaceTyping(typing, reply);

  } catch (err) {
    replaceTyping(typing, 'Something went wrong.');
    toast(`Request failed: ${err.message}`);
  } finally {
    isSending = false;
    sendBtn.disabled = !inputEl.value.trim();
  }
});

// ---------- rendering helpers ----------
function addUser(text){ return render('user', text); }
function addBot(text, isTyping=false){ return render('bot', text, isTyping); }

function render(role, content, isTyping=false){
  const node = tpl.content.firstElementChild.cloneNode(true);
  node.classList.add(role);
  const bubble = node.querySelector('.bubble');

  if (isTyping) {
    bubble.textContent = '.';
    bubble.classList.add('typing');
    startTyping(bubble);
    node.querySelector('.copy').remove(); // no copy for typing
  } else {
    setBubbleText(bubble, content);
    if (role === 'bot') wireCopy(node, bubble);
    else node.querySelector('.copy').remove();
  }

  chatEl.appendChild(node);
  chatEl.scrollTop = chatEl.scrollHeight;
  return node;
}

function replaceTyping(node, text){
  const bubble = node.querySelector('.bubble');
  stopTyping(bubble);
  bubble.classList.remove('typing');
  setBubbleText(bubble, text);
  wireCopy(node, bubble);
}

function setBubbleText(el, text){
  // safe text, preserve line breaks and bullets
  el.textContent = text;
  // enhance basic bullet look (optional, still text)
  // no innerHTML to avoid XSS; CSS handles wrapping
}

function wireCopy(node, bubble){
  const btn = node.querySelector('.copy');
  btn.addEventListener('click', async () => {
    try {
      await navigator.clipboard.writeText(bubble.textContent);
      toast('Copied!');
    } catch { toast('Copy failed'); }
  });
}

function autoGrow(el){
  el.style.height = 'auto';
  el.style.height = Math.min(el.scrollHeight, 180) + 'px';
  chatEl.scrollTop = chatEl.scrollHeight;
}

// typing dots
let typingTimer;
function startTyping(el){
  let dots = 1;
  typingTimer = setInterval(() => {
    dots = (dots % 3) + 1;
    el.textContent = '.'.repeat(dots);
  }, 400);
}
function stopTyping(){ clearInterval(typingTimer); }

function toast(msg){
  const div = document.createElement('div');
  div.className = 'toast';
  div.textContent = msg;
  document.body.appendChild(div);
  setTimeout(()=>div.remove(), 2200);
}
