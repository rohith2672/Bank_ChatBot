package com.bank.Bank_ChatBot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankChatBotApplicationTests {

	@Test
	void contextLoads() {
	}

}
